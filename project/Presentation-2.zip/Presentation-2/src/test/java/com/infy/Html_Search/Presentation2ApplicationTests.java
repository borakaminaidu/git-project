package com.infy.Html_Search;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Presentation2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
