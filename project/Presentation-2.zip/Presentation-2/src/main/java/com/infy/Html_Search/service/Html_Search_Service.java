package com.infy.Html_Search.service;

import java.io.IOException;

import java.util.ArrayList;
import java.util.List;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.infy.Html_Search.entity.Html_Search_Entity;
import com.infy.Html_Search.repository.Html_Search_Repository;

import jakarta.persistence.Entity;

@Component
public class Html_Search_Service {

	@Autowired
	private Html_Search_Repository repository;

	public List<String> searchKeyword(String html, String keyword) throws IOException {
		List<String> results = new ArrayList<>();
		List<Html_Search_Entity> list = new ArrayList<>();

		Document document = Jsoup.connect(html).get();

		Elements elements1 = document.select("table.Profile tr");

		Elements elements2 = elements1.select("td:nth-of-type(3)");
		for (Element element : elements2) {
			if (element.select(":contains(" + keyword + ")").text().equalsIgnoreCase("")) {
				continue;
			} else {
				results.add(element.select(":contains(" + keyword + ")").text());
			}

		}

		return results;

	}
	public List<String> traverseLinks(String html) throws IOException {
		List<String> results = new ArrayList<>();
		Document document = Jsoup.connect(html).get();
		Elements links = document.select("table.Profile tr");
		Elements link = links.select("td:nth-of-type(4)");
		int count=1;
		if (link.size() < 10) {
			for (Element element : link) {
				results.add(element.text());
			}
		} else {
			for (int i = 0; i <= 10; i++) {
				results.add(link.get(i).text());
			}
		}

		return results;
	}

	public List<String> getContentRepo(String keyword) {
		List<String> list1 = new ArrayList<>();
		for (Html_Search_Entity entity : repository.findAll()) {
			System.out.println(entity.getDescription()+"Descreption");
			if(entity.getKeyword().equalsIgnoreCase(keyword)||entity.getKeyword()==keyword) {
				list1.add(entity.getDescription());
			}
			else {list1.add("No data Base match");}
		}
		
		
		return list1;
	}
}
