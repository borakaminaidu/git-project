package com.infy.Html_Search;

import java.io.IOException;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScans;

import com.infy.Html_Search.controller.Html_Search_Controller;
import com.infy.Html_Search.repository.Html_Search_Repository;
import com.infy.Html_Search.service.Html_Search_Service;

@SpringBootApplication
public class Presentation2Application {

	public static void main(String[] args) {
		ConfigurableApplicationContext context = SpringApplication.run(Presentation2Application.class, args);
		Html_Search_Service service = context.getBean(Html_Search_Service.class);
		Html_Search_Controller controller = context.getBean(Html_Search_Controller.class);
		Html_Search_Repository repository = context.getBean(Html_Search_Repository.class);

	}
}
