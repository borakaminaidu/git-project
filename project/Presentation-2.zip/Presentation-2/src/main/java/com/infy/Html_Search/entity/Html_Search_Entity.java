package com.infy.Html_Search.entity;

import org.springframework.stereotype.Component;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Component
@Entity
@Table
@Data
public class Html_Search_Entity {
	@Id
	@Column(name = "id")
	private int id;
	@Column(name = "keyword")
	private String keyword;
	@Column(name = "description")
	private String description;
	
	public Html_Search_Entity() {
		super();
	}

	public Html_Search_Entity(int id, String keyword, String description) {
		super();
		this.id = id;
		this.keyword = keyword;
		this.description = description;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getKeyword() {
		return keyword;
	}
	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
}
