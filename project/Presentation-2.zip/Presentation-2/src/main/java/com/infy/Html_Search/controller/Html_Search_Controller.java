package com.infy.Html_Search.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.infy.Html_Search.repository.Html_Search_Repository;
import com.infy.Html_Search.service.Html_Search_Service;

@Controller
public class Html_Search_Controller {
	@Autowired
	public Html_Search_Service service;

	@Autowired
	public Html_Search_Repository repository;
	private String contentMessage;
	private String urlMessage;

	public String getUrlMessage() {
		return urlMessage;
	}

	public void setUrlMessage(String urlMessage) {
		this.urlMessage = urlMessage;
	}

	public void setContentMessage(String contentMessage) {
		this.contentMessage = contentMessage;
	}

	public String getContentMessage() {
		return contentMessage;
	}

	@GetMapping("/")
	public String home() {
		return "index";
	}

	@GetMapping("/getContent")
	public String getContent(@RequestParam String keyword, Model m) {

		String output = "";
		final String html = "http://127.0.0.1:5500/HTML_VS/Naidu_Html_Code.html";

		List<String> results1 = new ArrayList<>();

		try {
			results1 = service.searchKeyword(html, keyword);

			results1.addAll(service.getContentRepo(keyword));

			for (String result : results1) {
				output = output + " " + result;
			}
			System.out.println(output);
			if (output.length() > 0) {
				setContentMessage(output);
				m.addAttribute("output", getContentMessage());
			} else {
				setContentMessage("No match found");
				m.addAttribute("output", "Get Content");
			}

		} catch (IOException e) {
			e.getMessage();
		}

		return "content";

	}

	@GetMapping("/getUrls")
	public String getUrl(Model m) {

		final String html = "http://127.0.0.1:5500/HTML_VS/Naidu_Html_Code.html";
		List<String> results1 = new ArrayList<>();
		List<String> results2 = new ArrayList<>();
		try {
			results1 = service.traverseLinks(html);

			if (results1.size() < 10) {
				if (results1.size() > 0) {
					for (int i = 0; i < results1.size(); i++) {
						results2.add(results1.get(i)+" "+(i+1));

					}
					setUrlMessage(results2.toString());

					m.addAttribute("output", getUrlMessage());
				} else {
					setUrlMessage("No URL's");
				}
			} else {
				for (int i = 0; i < 10; i++) {
					results2.add(results1.get(i)+" "+(i+1));

				}
				if (results2.size() > 0) {
					setUrlMessage(results2.toString());

					m.addAttribute("output", getUrlMessage());
				} else {
					setUrlMessage("No URL's");
				}
			}

		} catch (IOException e) {
			e.getMessage();
		}

		return "url";

	}

	@GetMapping("/getUrl")
	public String getUrl(@RequestParam String keyword, Model m) {

		final String html = "http://127.0.0.1:5500/HTML_VS/Naidu_Html_Code.html";
		List<String> results1 = new ArrayList<>();
		List<String> results2 = new ArrayList<>();
		try {
			results1 = service.traverseLinks(html);
			for (String url : results1) {
				if (url.contains(keyword)) {
					results2.add(url);
				}

			}
			if (results2.size() > 0) {
				setUrlMessage(results2.toString());
				System.out.println("Output :" + getUrlMessage());
				m.addAttribute("output", getUrlMessage());
			} else {
				setUrlMessage("No URL's");
			}

		} catch (IOException e) {
			e.getMessage();
		}

		return "url";

	}
}
